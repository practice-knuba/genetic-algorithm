1. InitializePopulation
2. CalculateFunctionValue
3. ReproductionSelection
4. Crossingover
5. Mutation
6. AppendChilds
7. Reduction
