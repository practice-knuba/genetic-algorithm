#-*-coding: utf-8 -*-

class Individual:
    """
    Класс особи популяции
    """


    def __init__():
        self.x = 0
        self.y = 0


    def genes(self):
        """
        Возвращает массив генов 1/0
        """
        None
