#-*-coding: utf-8 -*-

class ReproductionSelection:
    """
    Осуществляет выбор родителей для размножения
    """

    def __init__(population):
        """
        Получает исходную популяцию
        """
        None


    def perform(self):
        """
        Возвращает отобранные пары родителей для кроссинговера
        [[ind1, ind2], [ind3, ind4]]
        """
        None
