#-*-coding: utf-8 -*-

class Crossingover:
    """
    Осуществляет скрещивание (кроссинговер) пар
    родителей
    """

    def __init__(parents_pairs):
        """
        Получает массив пар родителей
        """
        None


    def perform(self):
        """
        Возвращает массив особей-потомков родителей
        """
        None
