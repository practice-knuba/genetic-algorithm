#-*-coding: utf-8 -*-

class Reduction:
    """
    Сокращает популяцию
    """

    def __init__(population, population_size):
        """
        Принимает популяцию с потомками
        """
        None


    def perform(self):
        """
        Сокращает популяцию
        """
