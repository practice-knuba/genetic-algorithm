#-*-coding: utf-8 -*-

class AppendChilds:
    """
    Добавляет потомков в исходную популяцию
    """

    def __init__(population, childs):
        """
        Получает исходную популяцию и массив потомков
        """
        None


    def perform(self):
        """
        Добавляет потомков в популяцию
        """
        None
