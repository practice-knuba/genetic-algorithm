#-*-coding: utf-8 -*-

class InitializePopulation:
    """
    Инициализирует исходную популяцию
    """

    def __init__(population_size):
        """
        Получает параметр - размер популяции, записывает его
        в поле класса
        """
        None


    def perform(self):
        """
        Выполняет инициализацию популяции и возвращает ее
        """
        None
