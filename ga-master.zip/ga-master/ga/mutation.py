#-*-coding: utf-8 -*-

class Mutation:
    """
    Производит мутацию у потомков
    """

    def __init__(childs, probability):
        """
        Получает массив особей-потомков и вероятность мутации
        """
        None


    def perform(self):
        """
        Выполняет мутацию с заданной вероятностью
        """
        None
